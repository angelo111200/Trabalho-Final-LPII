package tracking;

public class Main {

    public static void main(String[] args) {
        new Frame.MainFrame().setVisible(true);
        
//        Classes Historico Atividade, Atividade e Perfil é para armazenar informações.
//        Classe MainFrame é a tela principal
//        Classe CrudPerfil e CrudAtividade é a tela para cadastro
//        Classe MainPDF é para gerar o relatorio em PDF

    }
    
}
