package DataBase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class HistoricoAtividade {
    
    private Perfil perfil;
    private Atividade atividade;
    private Date data;
    
    private SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");  
    
    public HistoricoAtividade(Perfil perfil,Atividade atividade,Date data){
        this.perfil = perfil;
        this.atividade = atividade;
        this.data = data;
    }
    
    public HistoricoAtividade(Perfil perfil,Atividade atividade,String data){
        this.perfil = perfil;
        this.atividade = atividade;
        try{
            this.data = format.parse(data);
        }
        catch(Exception e){}
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public Atividade getAtividade() {
        return atividade;
    }

    public Date getData() {
        return data;
    }
    
    public String getStringData(){
        return format.format(data); 
    }
    
}
