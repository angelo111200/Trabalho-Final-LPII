package DataBase;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Peso {
    
    private Perfil perfil;
    private double peso;
    private Date data;
    
    private SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");  
    
    public Peso(Perfil perfil,double peso,String data){
        this.perfil = perfil;
        this.peso = peso;
        try{
            this.data = format.parse(data);
        }
        catch(Exception e){}
        perfil.setPeso(peso);
    }
    
    public Peso(Perfil perfil,double peso,Date data){
        this.perfil = perfil;
        this.peso = peso;
        this.data = data;
        perfil.setPeso(peso);
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public double getPeso() {
        return peso;
    }

    public Date getData() {
        return data;
    }
    
    public String getStringData(){
        return format.format(data); 
    }
    
}
