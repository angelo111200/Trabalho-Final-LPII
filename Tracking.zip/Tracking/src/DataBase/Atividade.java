package DataBase;

public class Atividade {
    
    private String Nome;
    private int Tempo;
    private int Calorias;
    
    public Atividade(String Nome,int Tempo,int Calorias){
        this.Nome = Nome;
        this.Tempo = Tempo;
        this.Calorias = Calorias;
    }

    public String getNome() {
        return Nome;
    }

    public int getTempo() {
        return Tempo;
    }

    public int getCalorias() {
        return Calorias;
    }
    
}
