package DataBase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Perfil {
    
    private SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy"); 
    
    private String Nome;
    private Date DataNas;
    private double Peso,Altura;
    private int AtivDiaria=0,CaloDiaria=0;

    public Perfil(String Nome,String DataNas,double Peso,double Altura){
        this.Nome = Nome;
        try{
            this.DataNas = format.parse(DataNas);
        }
        catch(Exception e){}
        this.Peso = Peso;
        this.Altura = Altura;
        
    }
    
    public void setPeso(double Peso) {
        this.Peso = Peso;
    }

    public void setAtivDiaria(int AtivDiaria) {
        this.AtivDiaria = AtivDiaria;
    }

    public void setCaloDiaria(int CaloDiaria) {
        this.CaloDiaria = CaloDiaria;
    }

    public String getNome() {
        return Nome;
    }

    public int getIdade() {
        Date hoje = new Date();
        
        Calendar dateOfBirth = new GregorianCalendar();
        dateOfBirth.setTime(DataNas);
        Calendar today = Calendar.getInstance();
        
        int age = today.get(Calendar.YEAR) - dateOfBirth.get(Calendar.YEAR);
        dateOfBirth.add(Calendar.YEAR, age);
        
        if (today.before(dateOfBirth)) {
            age--;
        }
        
        return age;
    }

    public double getPeso() {
        return Peso;
    }

    public double getAltura() {
        return Altura;
    }

    public int getAtivDiaria() {
        return AtivDiaria;
    }

    public int getCaloDiaria() {
        return CaloDiaria;
    }
    
    public void defMetas(int RedAtivDiaria,int RedCalDiaria){
        AtivDiaria = RedAtivDiaria;
        CaloDiaria = RedCalDiaria;
    }
    
    public void AtualizarMeta(int CaloDiaria, int AtivDiaria){
        this.CaloDiaria -= CaloDiaria;
        this.AtivDiaria -= AtivDiaria;
    }
    
}
