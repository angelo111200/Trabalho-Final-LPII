package DataBase;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;

public class Controler{
    
    private ArrayList<Perfil> perfil = new ArrayList<>();
    private ArrayList<Atividade> atividade = new ArrayList<>();
    private ArrayList<HistoricoAtividade> historicoAtividade = new ArrayList<>();
    private ArrayList<Peso> historicoPeso = new ArrayList<>();
    
    
    public Controler(){
        
        Perfil eu1 = new Perfil("Felipe Jardim de Souza","22/03/1990",91.0,1.73);
        eu1.setAtivDiaria(60);
        eu1.setCaloDiaria(200);
        perfil.add(eu1);
        
        historicoPeso.add(new Peso(eu1,eu1.getPeso(),"22/04/2021"));
        
        Perfil eu2 = new Perfil("Ricardo Nogueira Alves","02/11/1974",89.0,1.73);
        eu2.setAtivDiaria(50);
        eu2.setCaloDiaria(300);
        perfil.add(eu2);
        
        atividade.add(new Atividade("3x10 Burpe", 15, 40));
        atividade.add(new Atividade("3x40 DU ou SU", 10, 15));
        atividade.add(new Atividade("3x12 VUp", 10, 20));
        atividade.add(new Atividade("3x60 PoliChinelo", 10, 30));
        atividade.add(new Atividade("3x5 Prancha alta", 15, 20));
        
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(0),"23/04/2021"));
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(3),"23/04/2021"));
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(2),"24/04/2021"));
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(4),"25/04/2021"));
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(2),"25/04/2021"));
        historicoAtividade.add(new HistoricoAtividade(eu1, atividade.get(1),"28/04/2021"));
        
        historicoPeso.add(new Peso(eu1, 89, "23/04/2021"));
        historicoPeso.add(new Peso(eu1, 85, "26/04/2021"));
        historicoPeso.add(new Peso(eu1, 81, "29/04/2021"));
    }
    
    public int HistoricoAtividadeSize(){
        return historicoAtividade.size();
    }
    
    public int HistoricoPesoSize(){
        return historicoPeso.size();
    }
    
    public HistoricoAtividade getHistoricoAtividade(int Index){
        return historicoAtividade.get(Index);
    }
    
    public Peso getHistoricoPeso(int Index){
        return historicoPeso.get(Index);
    }
    
    public void regisAtividade(Perfil perfil,Atividade atividade){
        historicoAtividade.add(new HistoricoAtividade(perfil, atividade, new Date()));
    }
    
    public void InfoNovoPeso(Perfil perfil,double peso){
        historicoPeso.add(new Peso(perfil, peso, new Date()));
    }
    
    public int getTotalTempoAtividade(Perfil perfil){
        int valor = 0;
        
        for(int i=0;i<historicoAtividade.size();i++){
            if(historicoAtividade.get(i).getPerfil()==perfil && isToday(historicoAtividade.get(i).getData())){
                
                valor += historicoAtividade.get(i).getAtividade().getTempo();
            }
        }
        
        return valor;
    }
    
    public int getTotalCalorias(Perfil perfil){
        int valor = 0;
        
        for(int i=0;i<historicoAtividade.size();i++){
            if(historicoAtividade.get(i).getPerfil()==perfil && isToday(historicoAtividade.get(i).getData())){
                valor += historicoAtividade.get(i).getAtividade().getCalorias();
            }
        }
        
        return valor;
    }
    
    public boolean isToday(Date date){
        Date Today = new Date();
        
        boolean Dia = Today.getDate()==date.getDate();
        boolean Mes = Today.getMonth()==date.getMonth();
        boolean Ano = Today.getYear()==Today.getYear();
        
        return Dia && Mes && Ano ;
    }
    
    public int DaysUntil(Date Inicial,Date Final){
        LocalDate dtI = Inicial.toInstant().atZone(ZoneId.systemDefault().systemDefault()).toLocalDate();
        LocalDate dtF = Final.toInstant().atZone(ZoneId.systemDefault().systemDefault()).toLocalDate();
        
        long dias = ChronoUnit.DAYS.between(dtI, dtF);
        
        return (int)dias;
    }
    
    public void addPerfil(String Nome,String DataNasc,double Peso,double altura,int AtivDiaria,int CaloDiaria){
        Perfil p = new Perfil(Nome, DataNasc, Peso, altura);
        p.setAtivDiaria(AtivDiaria);
        p.setCaloDiaria(CaloDiaria);
        perfil.add(p);
        historicoPeso.add(new Peso(p,p.getPeso(), new Date()));
    }
    
    public void addAtividade(String Nome,int Tempo,int Caloria){
        atividade.add(new Atividade(Nome, Tempo, Caloria));
    }
    
    public Perfil getPerfil(int Index){
        return perfil.get(Index);
    }

    public Atividade getAtividade(int Index){
        return atividade.get(Index);
    }
    
    public String[] getListaAtividade(){
        String Nomes = "";
        
        for(int i=0;i<atividade.size();i++){
            Nomes = Nomes + atividade.get(i).getNome()+",";
        }
        
        return Nomes.split(",");
    }
    
    public String[] getListaPerfil(){
        String Nomes = "";
        
        for(int i=0;i<perfil.size();i++){
            Nomes = Nomes + perfil.get(i).getNome()+",";
        }
        
        return Nomes.split(",");
    }
    
}
