package Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import DataBase.Controler;
import PDF.MainPDF;
import javax.swing.JTextField;

public class MainFrame extends JFrame implements ActionListener,ItemListener{
    
    private Controler db = new Controler();
    private MainPDF PDF = new MainPDF(db);
    
    private CrudPerfil crudPerfil;
    private CrudAtividade crudAtividade;
    
    private JComboBox ListPerfil,ListAtividade;
    private JButton CradPerfil,CradAtividade,AplicAtividade,RelatorioAtividade,InfoPeso;
    private JLabel Nome,Idade,Peso,Altura,AtivDiaria,CaloDiaria;
    private JLabel SelAtividade,NomeAtiv,TempoAtiv,CaloAtiv;
    private JLabel MetAtivDiaria,MetCaloDiaria,PesoAtual;
    private JTextField NovoPeso;
    
    public MainFrame(){
        super("Tracking");
        
        this.setSize(800,500);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        ListPerfil = new JComboBox();
        ListPerfil.setBounds(10,10,300,20);
        updateListPerfil(0);
        ListPerfil.addItemListener(this);
        this.add(ListPerfil);
        
        CradPerfil = new JButton("Cadastrar Novo Perfil");
        CradPerfil.setBounds(570,10,200,20);
        CradPerfil.addActionListener(this);
        this.add(CradPerfil);
        
        CradAtividade = new JButton("Cadastrar Nova Atividade");
        CradAtividade.setBounds(570,30,200,20);
        CradAtividade.addActionListener(this);
        this.add(CradAtividade);
        
        RelatorioAtividade = new JButton("Relatorio de Atividade");
        RelatorioAtividade.setBounds(570,50,200,20);
        RelatorioAtividade.addActionListener(this);
        this.add(RelatorioAtividade);
        
        Nome = new JLabel();
        Nome.setBounds(10,50,300,20);
        this.add(Nome);
        
        Idade = new JLabel();
        Idade.setBounds(10,70,300,20);
        this.add(Idade);
        
        Peso = new JLabel();
        Peso.setBounds(10,90,300,20);
        this.add(Peso);
        
        Altura = new JLabel();
        Altura.setBounds(10,110,300,20);
        this.add(Altura);
        
        AtivDiaria = new JLabel();
        AtivDiaria.setBounds(10,130,300,20);
        this.add(AtivDiaria);
        
        CaloDiaria = new JLabel();
        CaloDiaria.setBounds(10,150,300,20);
        this.add(CaloDiaria);
        
        MetAtivDiaria = new JLabel();
        MetAtivDiaria.setBounds(10,170,300,20);
        this.add(MetAtivDiaria);
        
        MetCaloDiaria = new JLabel();
        MetCaloDiaria.setBounds(10,190,300,20);
        this.add(MetCaloDiaria);
                
        SelAtividade = new JLabel("Selecione a atividade:");
        SelAtividade.setBounds(10,230,300,20);
        this.add(SelAtividade);
        
        ListAtividade = new JComboBox();
        ListAtividade.setBounds(10,250,300,20);
        updateListAtividade();
        ListAtividade.addItemListener(this);
        this.add(ListAtividade);
        
        NomeAtiv = new JLabel();
        NomeAtiv.setHorizontalAlignment(SwingConstants.CENTER);
        NomeAtiv.setBounds(10,270,300,20);
        this.add(NomeAtiv); 
        
        TempoAtiv = new JLabel();
        TempoAtiv.setHorizontalAlignment(SwingConstants.CENTER);
        TempoAtiv.setBounds(10,290,300,20);
        this.add(TempoAtiv);
        
        CaloAtiv = new JLabel();
        CaloAtiv.setHorizontalAlignment(SwingConstants.CENTER);
        CaloAtiv.setBounds(10,310,300,20);
        this.add(CaloAtiv);
        
        AplicAtividade = new JButton("Aplicar Atividade no Perfil");
        AplicAtividade.setBounds(10,330,300,20);
        AplicAtividade.addActionListener(this);
        this.add(AplicAtividade);
        
        PesoAtual = new JLabel("Informar Novo Peso:");
        PesoAtual.setBounds(10,370,300, 20);
        this.add(PesoAtual);
        
        NovoPeso = new JTextField();
        NovoPeso.setBounds(10,395,300, 20);
        this.add(NovoPeso);
        
        InfoPeso = new JButton("Atualizar Peso");
        InfoPeso.setBounds(10,420,300, 20);
        InfoPeso.addActionListener(this);
        this.add(InfoPeso);
        
        updatePerfil(0);
        updateAtividade(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == CradPerfil){
            if(crudPerfil == null){
                crudPerfil = new CrudPerfil(db,this);
            }
            crudPerfil.setVisible(true);
        }
        if(e.getSource() == CradAtividade){
            if(crudAtividade == null){
                crudAtividade = new CrudAtividade(db,this);
            }
            crudAtividade.setVisible(true);
        }
        if(e.getSource() == AplicAtividade){
            db.regisAtividade(db.getPerfil(ListPerfil.getSelectedIndex()),db.getAtividade(ListAtividade.getSelectedIndex()));
            
            updateListPerfil(ListPerfil.getSelectedIndex()); 
        }
        if(e.getSource() == RelatorioAtividade){
            PDF.setPerfil(db.getPerfil(ListPerfil.getSelectedIndex()));
            PDF.start(this);
            //PDF.create("C:\\Relatorio_Atividades.pdf");
        }
        if(e.getSource() == InfoPeso){
            db.InfoNovoPeso(db.getPerfil(ListPerfil.getSelectedIndex()),Double.valueOf(NovoPeso.getText()));
            updateListPerfil(ListPerfil.getSelectedIndex());
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if(e.getSource() == ListPerfil && e.getStateChange() == 1){
            updatePerfil(ListPerfil.getSelectedIndex());
        }
        if(e.getSource() == ListAtividade && e.getStateChange() == 1){
            updateAtividade(ListAtividade.getSelectedIndex());
        }
    }
    
    public void updateAtividade(int index){
        NomeAtiv.setText("---"+db.getAtividade(index).getNome()+"---");
        TempoAtiv.setText("---Tempo: "+db.getAtividade(index).getTempo()+" Minutos---");
        CaloAtiv.setText("---Calorias: "+db.getAtividade(index).getCalorias()+"---");
    }
    
    public void updateListAtividade(){
        Object[] lista = db.getListaAtividade();
        ListAtividade.removeAllItems();
        for(int i=0;i<lista.length;i++){
            ListAtividade.addItem(lista[i]);
        }
    }
    
    public void updatePerfil(int index){
        Nome.setText("Nome: "+db.getPerfil(index).getNome());
        Idade.setText("Idade: "+db.getPerfil(index).getIdade());
        Peso.setText("Peso: "+db.getPerfil(index).getPeso());
        Altura.setText("Altura: "+db.getPerfil(index).getAltura());
        AtivDiaria.setText("Meta- Tempo de atividade Diaria: "+db.getPerfil(index).getAtivDiaria()+" Min");
        CaloDiaria.setText("Meta- Calorias Diarias: "+db.getPerfil(index).getCaloDiaria());
        
        MetAtivDiaria.setText("Tempo de atividade Cumprido: "+db.getTotalTempoAtividade(db.getPerfil(index)));
        MetCaloDiaria.setText("Calorias Cumpridas: "+db.getTotalCalorias(db.getPerfil(index)));
    }
    
    public void updateListPerfil(int index){
        Object[] lista = db.getListaPerfil();
        
        ListPerfil.removeAllItems();
        for(int i=0;i<lista.length;i++){
            ListPerfil.addItem(lista[i]);
        }
        
        ListPerfil.setSelectedIndex(index);
    }
    
}
