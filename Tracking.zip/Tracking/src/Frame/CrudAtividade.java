package Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import DataBase.Controler;

public class CrudAtividade extends JFrame implements WindowListener,ActionListener{
    
    private Controler db;
    private MainFrame main;
    
    private JLabel LNome,LTempo,LCaloria;
    private JTextField TNome,TTempo,TCaloria;
    private JButton Cadastrar;
    
    public CrudAtividade(Controler db,MainFrame main){
        super("Nova Atividade");
        
        this.db = db;
        this.main = main;
                
        this.setSize(300,400);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.addWindowListener(this);
        
        LNome = new JLabel("Nome");
        LNome.setBounds(10,10,140,20);
        this.add(LNome);
        
        TNome = new JTextField();
        TNome.setBounds(10,30,260,20);
        this.add(TNome);
        
        LTempo = new JLabel("Duração (em Min)");
        LTempo.setBounds(10,60,140,20);
        this.add(LTempo);
        
        TTempo = new JTextField();
        TTempo.setBounds(10,80,260,20);
        this.add(TTempo);
        
        LCaloria = new JLabel("Calorias");
        LCaloria.setBounds(10,110,260,20);
        this.add(LCaloria);
        
        TCaloria = new JTextField();
        TCaloria.setBounds(10,130,260,20);
        this.add(TCaloria);
        
        Cadastrar = new JButton("Cadastrar Atividade");
        Cadastrar.setBounds(10,320, 260,30);
        Cadastrar.addActionListener(this);
        this.add(Cadastrar);
    }

    public void Limpar(){
        TNome.setText("");
        TTempo.setText("");
        TCaloria.setText("");
    }
    
    @Override
    public void windowOpened(WindowEvent e) {
        Limpar();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        Limpar();
    }

    @Override
    public void windowClosed(WindowEvent e) {}

    @Override
    public void windowIconified(WindowEvent e) {}

    @Override
    public void windowDeiconified(WindowEvent e) {}

    @Override
    public void windowActivated(WindowEvent e) {}

    @Override
    public void windowDeactivated(WindowEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == Cadastrar){
            String Nome = TNome.getText();
            int tempo = Integer.parseInt(TTempo.getText());
            int calor = Integer.parseInt(TCaloria.getText());
            
            db.addAtividade(Nome, tempo, calor);
            main.updateListAtividade();
            Limpar();
            this.setVisible(false);
        }
    }
    
}
