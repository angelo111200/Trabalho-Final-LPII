package Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;
import DataBase.Controler;

public class CrudPerfil extends JFrame implements WindowListener,ActionListener{
    
    private Controler db;
    private MainFrame main;
    
    private MaskFormatter ftmDataNas,ftmPeso,ftmAltura;
    
    private JFormattedTextField TDataNas,TPeso,TAltura;
    private JLabel LNome,LDataNas,LPeso,LAltura,LAtivDiaria,LCaloDiaria;
    private JTextField TNome,TAtivDiaria,TCaloDiaria;
    private JButton Cadastrar;
    
    public CrudPerfil(Controler db,MainFrame main){
        super("Novo Perfil");
        
        this.db = db;
        this.main = main;
        
        formaters();
        
        this.setSize(300,400);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.addWindowListener(this);
        
        LNome = new JLabel("Nome");
        LNome.setBounds(10,10,140,20);
        this.add(LNome);
        
        TNome = new JTextField();
        TNome.setBounds(10,30,260,20);
        this.add(TNome);
        
        LDataNas = new JLabel("Data de Nascimento");
        LDataNas.setBounds(10,60,140,20);
        this.add(LDataNas);
        
        TDataNas = new JFormattedTextField(ftmDataNas);
        TDataNas.setBounds(10,80,260,20);
        this.add(TDataNas);
        
        LPeso = new JLabel("Peso (Em KG)");
        LPeso.setBounds(10,110,260,20);
        this.add(LPeso);
        
        TPeso = new JFormattedTextField();
        TPeso.setBounds(10,130,260,20);
        this.add(TPeso);
        
        LAltura = new JLabel("Altura (em Metros)");
        LAltura.setBounds(10,160,260,20);
        this.add(LAltura);
        
        TAltura = new JFormattedTextField(ftmAltura);
        TAltura.setBounds(10,180,260,20);
        this.add(TAltura);
        
        LAtivDiaria = new JLabel("Meta: Tempo de Atividade Diaria(em Min)");
        LAtivDiaria.setBounds(10,210,260,20);
        this.add(LAtivDiaria);
        
        TAtivDiaria = new JTextField();
        TAtivDiaria.setBounds(10,230,260,20);
        this.add(TAtivDiaria);
        
        LCaloDiaria = new JLabel("Meta: Calorias Diarias");
        LCaloDiaria.setBounds(10,260,140,20);
        this.add(LCaloDiaria);
        
        TCaloDiaria = new JTextField();
        TCaloDiaria.setBounds(10,280,260,20);
        this.add(TCaloDiaria);
        
        Cadastrar = new JButton("Cadastrar Perfil");
        Cadastrar.setBounds(10,320, 260,30);
        Cadastrar.addActionListener(this);
        this.add(Cadastrar);
    }

    public void formaters(){
        try{
            ftmPeso = new MaskFormatter("###");
            ftmAltura = new MaskFormatter("#.##");
            ftmDataNas = new MaskFormatter("##/##/####");
        }catch(Exception e){}
    }
    
    public void Limpar(){
        TNome.setText("");
        TDataNas.setText("");
        TPeso.setText("");
        TAltura.setText("");
        TAtivDiaria.setText("");
        TCaloDiaria.setText("");
    }
    
    @Override
    public void windowOpened(WindowEvent e) {
        Limpar();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        Limpar();
    }

    @Override
    public void windowClosed(WindowEvent e) {}

    @Override
    public void windowIconified(WindowEvent e) {}

    @Override
    public void windowDeiconified(WindowEvent e) {}

    @Override
    public void windowActivated(WindowEvent e) {}

    @Override
    public void windowDeactivated(WindowEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == Cadastrar){
            double peso = Double.valueOf(TPeso.getText());
            double altura = Double.valueOf(TAltura.getText());
            int metaAtivDiaria = Integer.parseInt(TAtivDiaria.getText());
            int metaCaloDiaria = Integer.parseInt(TCaloDiaria.getText());
            
            db.addPerfil(TNome.getText(),TDataNas.getText(),peso,altura,metaAtivDiaria,metaCaloDiaria);
            
            main.updateListPerfil(0);
            Limpar();
            this.setVisible(false);
        }
    }
    
}
