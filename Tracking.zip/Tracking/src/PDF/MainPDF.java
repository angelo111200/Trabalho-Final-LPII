package PDF;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import java.io.FileOutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javax.swing.JFileChooser;
import DataBase.Atividade;
import DataBase.Controler;
import DataBase.HistoricoAtividade;
import DataBase.Perfil;
import DataBase.Peso;
import Frame.MainFrame;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainPDF {
    
    private Controler db;
    private Perfil perfil;
    
    public MainPDF(Controler db){
        this.db = db;
    }
    
    public void setPerfil(Perfil perfil){
        this.perfil = perfil;
    }
    
    public void start(MainFrame parent){
        //create("C:\\Users\\acelu\\Desktop\\PDF_DevMedia.pdf");
        
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("arquivo");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);
        
        if (chooser.showSaveDialog(parent) == JFileChooser.APPROVE_OPTION) {
            create(chooser.getSelectedFile().getPath()+"\\Relatorio_Atividades.pdf");
        }
    }
    
    public void create(String URL){
        Document document = new Document();
        try {
            
            PdfWriter.getInstance(document, new FileOutputStream(URL));
            document.open();

            document.addTitle("Relariorio "+perfil.getNome());
            
            Font FTitulo = FontFactory.getFont(FontFactory.COURIER_BOLD, 18f);
            Font FTabela = FontFactory.getFont(FontFactory.COURIER_BOLD, 12f);
            Font Finfos = FontFactory.getFont(FontFactory.COURIER, 14f);
            
            Phrase PTitulo = new Phrase(2f,"Relatorio de atividades",FTitulo);
            Paragraph Titulo = new Paragraph(PTitulo);
            Titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(Titulo);
            
            document.add( Chunk.NEWLINE );
            
            int[] Widths1 = {9,19,6,6};
            PdfPTable table1 = new PdfPTable(Widths1.length);
            table1.setWidths(Widths1);
            
            int[] Widths2 = {9,6,6};
            PdfPTable table2 = new PdfPTable(Widths2.length);
            table2.setWidths(Widths2);
            
            PdfPCell TopNome = new PdfPCell(new Phrase(2f,perfil.getNome(),FTabela));
            PdfPCell TopData = new PdfPCell(new Phrase(2f,"Data",FTabela));
            PdfPCell TopAtiv = new PdfPCell(new Phrase(2f,"Atividade",FTabela));
            PdfPCell TopTemp = new PdfPCell(new Phrase(2f,"Tempo",FTabela));
            PdfPCell TopCalo = new PdfPCell(new Phrase(2f,"Calorias",FTabela));
            
            PdfPCell PesTopo = new PdfPCell(new Phrase(2f,"Historico de peso",FTabela));
            PdfPCell PesData = new PdfPCell(new Phrase(2f,"Data",FTabela));
            PdfPCell PesPeso = new PdfPCell(new Phrase(2f,"Peso",FTabela));
            PdfPCell PesDife = new PdfPCell(new Phrase(2f,"Diferença",FTabela));
            
            TopNome.setBackgroundColor(BaseColor.GRAY);
            TopData.setBackgroundColor(BaseColor.LIGHT_GRAY);
            TopAtiv.setBackgroundColor(BaseColor.LIGHT_GRAY);
            TopTemp.setBackgroundColor(BaseColor.LIGHT_GRAY);
            TopCalo.setBackgroundColor(BaseColor.LIGHT_GRAY);
            
            PesTopo.setBackgroundColor(BaseColor.GRAY);
            PesTopo.setBackgroundColor(BaseColor.LIGHT_GRAY);
            PesData.setBackgroundColor(BaseColor.LIGHT_GRAY);
            PesPeso.setBackgroundColor(BaseColor.LIGHT_GRAY);
            PesDife.setBackgroundColor(BaseColor.LIGHT_GRAY);
            
            TopNome.setColspan(4);
            TopNome.setHorizontalAlignment(Element.ALIGN_CENTER);
            TopData.setHorizontalAlignment(Element.ALIGN_CENTER);
            TopAtiv.setHorizontalAlignment(Element.ALIGN_CENTER);
            TopTemp.setHorizontalAlignment(Element.ALIGN_CENTER);
            TopCalo.setHorizontalAlignment(Element.ALIGN_CENTER);
            
            PesTopo.setColspan(3);
            PesTopo.setHorizontalAlignment(Element.ALIGN_CENTER);
            PesData.setHorizontalAlignment(Element.ALIGN_CENTER);
            PesPeso.setHorizontalAlignment(Element.ALIGN_CENTER);
            PesDife.setHorizontalAlignment(Element.ALIGN_CENTER);
            
            table1.addCell(TopNome);
            table1.addCell(TopData);
            table1.addCell(TopAtiv);
            table1.addCell(TopTemp);
            table1.addCell(TopCalo);
            
            table2.addCell(PesTopo);
            table2.addCell(PesData);
            table2.addCell(PesPeso);
            table2.addCell(PesDife);
            
            for(int i=0;i<db.HistoricoAtividadeSize();i++){
                HistoricoAtividade ha = db.getHistoricoAtividade(i);
                if(ha.getPerfil() == perfil){
                    Atividade at = ha.getAtividade();
                    
                    table1.addCell(new PdfPCell(new Phrase(2f,ha.getStringData(),Finfos)));
                    table1.addCell(new PdfPCell(new Phrase(2f,at.getNome(),Finfos)));
                    table1.addCell(new PdfPCell(new Phrase(2f,at.getTempo()+" Min",Finfos)));
                    table1.addCell(new PdfPCell(new Phrase(2f,at.getCalorias()+"",Finfos)));
                }
            }
            
            double antes = -1;
            for(int i=0;i<db.HistoricoPesoSize();i++){
                Peso pe = db.getHistoricoPeso(i);
                if(pe.getPerfil() == perfil){
                    table2.addCell(new PdfPCell(new Phrase(2f,pe.getStringData(),Finfos)));
                    table2.addCell(new PdfPCell(new Phrase(2f,pe.getPeso()+" KG",Finfos)));
                    if(antes != -1){
                        table2.addCell(new PdfPCell(new Phrase(2f,(pe.getPeso()-antes)+" KG",Finfos)));
                    }
                    else{
                        table2.addCell(new PdfPCell(new Phrase(2f,"Peso Inicial",Finfos)));
                    }
                    antes = pe.getPeso();
                }
            }
            
            document.add(table1);
            
            for(int i=0;i<12;i++){
                document.add( Chunk.NEWLINE );
            }
            
            document.add(table2);
                        
            for(int i=0;i<12;i++){
                document.add( Chunk.NEWLINE );
            }
            
            int IndexInicial=-1,IndexFinal=0;
            
            for(int i=0;i<db.HistoricoPesoSize();i++){
                Peso pe = db.getHistoricoPeso(i);
                if(pe.getPerfil() == perfil){
                    if(IndexInicial == -1){
                        IndexInicial = i;
                    }
                    IndexFinal = i;
                }
            }
            
            double PesoInicial = db.getHistoricoPeso(IndexInicial).getPeso();
            double PesoFinal = db.getHistoricoPeso(IndexFinal).getPeso();
            double alterPeso = PesoInicial - PesoFinal;
            String Textopeso = "Perda de peso de "+alterPeso+" KG";
            if(alterPeso < 0){
                alterPeso = alterPeso*-1;
                Textopeso = "Ganho de peso de "+alterPeso+" KG";
            }
            
            Date DInicio = db.getHistoricoPeso(IndexInicial).getData();
            Date DFinal = db.getHistoricoPeso(IndexFinal).getData();
            
            Textopeso += " em "+db.DaysUntil(DInicio,DFinal)+" dias.";
            
            Phrase PAlterPeso = new Phrase(2f,Textopeso,FTabela);
            Paragraph AlterPeso = new Paragraph(PAlterPeso);
            AlterPeso.setAlignment(Element.ALIGN_CENTER);
            document.add(AlterPeso);
            
            for(int i=0;i<6;i++){
                document.add( Chunk.NEWLINE );
            }
            
            double PesoDiario = alterPeso/db.DaysUntil(DInicio,DFinal);
            String SExpecPeso = "Espera-se perder "+((int)(PesoDiario*5))+" KG nos proximos 5 dias.";
            
            Phrase PExpecPeso = new Phrase(2f,SExpecPeso,FTabela);
            Paragraph ExpecPeso = new Paragraph(PExpecPeso);
            ExpecPeso.setAlignment(Element.ALIGN_CENTER);
            document.add(ExpecPeso);
            
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
        document.close();
    }
    
    
    
}
